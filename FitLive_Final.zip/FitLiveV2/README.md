# FitLive – Real-Time Fitness Tracker
### Team: Tech Titans | Course: FS-VI-T122

---

## Quick Start (3 commands)

```bash
# 1. Start MongoDB (must be running first)
net start MongoDB          # Windows
brew services start mongodb-community   # macOS

# 2. Install packages (only once)
npm install

# 3. Run the app
npm start
```

Open browser → http://localhost:3000

---

## Google Fit Setup (for live data)

1. Go to https://console.cloud.google.com → New project
2. Enable **Fitness API**
3. OAuth consent screen → External → Add scopes:
   `fitness.activity.read`, `fitness.heart_rate.read`, `fitness.body.read`
   → Test Users: add your Gmail
4. Credentials → OAuth 2.0 Client ID → Web app
   → Redirect URI: `http://localhost:3000/googlefit/callback`
5. Edit `.env` file:
   ```
   GOOGLE_CLIENT_ID=paste_here
   GOOGLE_CLIENT_SECRET=paste_here
   ```
6. Restart server → Login → Google Fit page → Connect

> Without Google credentials the app still works with simulated data.

---

## Tech Stack
- **Backend**: Node.js, Express.js
- **Database**: MongoDB + Mongoose
- **Real-Time**: Socket.io (WebSockets)
- **Google Fit**: googleapis (OAuth2)
- **Frontend**: EJS, CSS, Chart.js
- **Auth**: bcryptjs, express-session

---

## Team Members
| Name | Roll No | Email |
|------|---------|-------|
| Somya Joshi (Lead) | 23022853 | Joshisomya82@gmail.com |
| Vaishali Nain | 23022148 | Vaishalinain2004@gmail.com |
| Mukul Dev | 230213681 | mdev97455@gmail.com |
| Kshitiz Singh | 23011679 | kshitizsingh1408@gmail.com |
